from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_AuthForm(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 115)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(Form)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.login_line = QtWidgets.QLineEdit(Form)
        self.login_line.setObjectName("login_line")
        self.verticalLayout.addWidget(self.login_line)
        self.password_line = QtWidgets.QLineEdit(Form)
        self.password_line.setObjectName("password_line")
        self.verticalLayout.addWidget(self.password_line)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.auth_btn = QtWidgets.QPushButton(Form)
        self.auth_btn.setObjectName("auth_btn")
        self.horizontalLayout.addWidget(self.auth_btn)
        self.reg_btn = QtWidgets.QPushButton(Form)
        self.reg_btn.setObjectName("reg_btn")
        self.horizontalLayout.addWidget(self.reg_btn)
        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.login_line.setPlaceholderText(_translate("Form", "Логин"))
        self.password_line.setPlaceholderText(_translate("Form", "Пароль"))
        self.auth_btn.setText(_translate("Form", "Авторизация"))
        self.reg_btn.setText(_translate("Form", "Регистрация"))
