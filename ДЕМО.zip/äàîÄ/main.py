import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QMessageBox, QMainWindow
from auth import Ui_Form
from app_ui import Ui_MainWindow
import psycopg2


class DatabaseConnection:
    def __init__(self):
        self.con = psycopg2.connect(
            host='10.163.31.228',
            database='rpr',
            user='yakovlenkova_v',
            password='yakovlenkova_v'
        )
        self.cur = self.con.cursor()

    def close(self):
        self.cur.close()
        self.con.close()

    def fetch_all_data(self):
        query = "SELECT * FROM \"Product\""
        self.cur.execute(query)
        return self.cur.fetchall()


class AuthForm(QWidget):
    def __init__(self, db_con):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.db_con = db_con
        self.main_window = MainWindow(db_con)

        self.ui.pushButton_login.clicked.connect(self.auth_btn_clicked)
        self.ui.pushButton_signup.clicked.connect(self.reg_btn_clicked)

    def auth_btn_clicked(self):
        login = self.ui.lineEdit_login.text()
        password = self.ui.lineEdit_password.text()

        query = "SELECT login, password FROM \"User\" WHERE login = %s AND password = %s"
        self.db_con.cur.execute(query, (login, password))

        if self.db_con.cur.fetchone() is None:
            QMessageBox.warning(self, "Ошибка", f"Пользователь {login} не существует или введён неверный пароль!")
        else:
            QMessageBox.information(self, "Успех", f"Успешная аутентификация под логином {login}!")
            self.hide()
            self.main_window.show()

    def reg_btn_clicked(self):
        login = self.ui.lineEdit_login.text()
        password = self.ui.lineEdit_password.text()

        query = "SELECT login, password FROM \"User\" WHERE login = %s"
        self.db_con.cur.execute(query, (login,))
        if self.db_con.cur.fetchone() is None:
            query = "INSERT INTO \"User\" (login, password) VALUES (%s, %s)"
            self.db_con.cur.execute(query, (login, password))
            self.db_con.con.commit()
            QMessageBox.information(self, "Успех", f"Успешная регистрация под {login}!")
        else:
            QMessageBox.warning(self, "Ошибка", f"Пользователь {login} уже существует!")

    def closeEvent(self, event):
        self.db_con.close()
        self.main_window.close()


class MainWindow(QMainWindow):
    def __init__(self, db_con):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.db_con = db_con

        self.ui.update_btn.clicked.connect(self.update_btn_clicked)

    def update_btn_clicked(self):
        data = self.db_con.fetch_all_data()

        self.ui.tableWidget.setRowCount(len(data))
        for row_index, row_data in enumerate(data):
            for col_index, col_data in enumerate(row_data):
                item = QtWidgets.QTableWidgetItem(str(col_data))
                self.ui.tableWidget.setItem(row_index, col_index, item)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    db_connection = DatabaseConnection()
    form = AuthForm(db_connection)
    form.show()
    sys.exit(app.exec_())
